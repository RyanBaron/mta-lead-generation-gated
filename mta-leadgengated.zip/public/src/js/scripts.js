(function( $ ) {
  'use strict';

  /**
   * All of the code for your admin-facing JavaScript source
   * should reside in this file.
   *
   * Note: It has been assumed you will write jQuery code here, so the
   * $ function reference has been prepared for usage within the scope
   * of this function.
   *
   * This enables you to define handlers, for when the DOM is ready:
   *
   * $(function() {
   *
   * });
   *
   * When the window is loaded:
   *
   * $( window ).load(function() {
   *
   * });
   *
   * ...and/or other possibilities.
   *
   * Ideally, it is not considered best practise to attach more than a
   * single DOM-ready or window-load handler for a particular page.
   * Although scripts in the WordPress core, Plugins and Themes may be
   * practising this, we should strive to set a better example in our own work.
   */

  /*
  $.MTAleadgengated = function (element) { //renamed arg for readability
    //store the passed element as a property of the created instance.
    this.element = (element instanceof $) ? element : $(element);

    //if avaliable, get some information stored in a local variable
    this.leadgen_timer      = element.data('leadgen-timer');
    this.leadgen_trigger    = element.data('leadgen-trigger');
    this.local_storage_key  = element.data('page-name');
    this.local_storage      = JSON.parse(localStorage.getItem(this.local_storage_key));
    this.dismissed_time     = (this.local_storage !== null) ? (typeof this.local_storage.dismissedTime !== 'undefined') ? this.local_storage.dismissedTime : 0 : 0;
  };
  */

  /*
  $.MTAleadgengated.prototype = {

    init: function () {
      //`this` references the instance object inside of an instace's method,
      //however `this` is set to reference a DOM element inside jQuery event
      //handler functions' scope. So we take advantage of JS's lexical scope
      //and assign the `this` reference to another variable that we can access
      //inside the jQuery handlers

      var that = this;

      switch(this.leadgen_trigger) {

        case 'exit':
          //show the restrict when the users mouse leaves the page
          $(document).on('mouseleave', mouseLeavePage);
          break;

        case 'timer':
          //show the restrict after a specified amount of time
          setTimeout(function() {
            timeTrigger();
          }, this.leadgen_timer);
          break;

        case 'exit-and-timer':
          //show the restrict after a specified amount of time, or when the users mouse leaves the page, whichever come first
          setTimeout(function() {
            timeTrigger();
          }, this.leadgen_timer);

          $(document).on('mouseleave', mouseLeavePage);
          break;
      }

      function mouseLeavePage(e){
        //trigger the restrict event
        that.triggerRestrict('Lead Generation - Page Exit Restrict');

        //trigger an analytics event
        //that.triggerAnalyticsEvent('Lead Generation Gated', 'Page Exit', that.local_storage_key, 1);
      }

      function timeTrigger(){
        that.triggerRestrict('Lead Generation - Page Timer Restrict: ' + (that.leadgen_timer/1000) + 's');

        //trigger an analytics event
        //that.triggerAnalyticsEvent('Lead Generation Gated', 'Page Timer - ' + that.leadgen_timer, that.local_storage_key, 1);
      }

      $('body').on('click', '.close-mta-leadgengated', function(e) {
        e.preventDefault();
        //store the restrict item and time it was dismissed in local storage
        var closeItem = $(this).data('leadgenclose');
        var object = {pageName: closeItem, dismissedTime: new Date().getTime()};
        localStorage.setItem(closeItem, JSON.stringify(object));

        //trigger an analytics event
        that.triggerAnalyticsEvent('Lead Generation Gated', 'Lead Generation - Dismiss Restrict', that.local_storage_key, 1);

        //reset the last dismissed time
        that.reset();
        //remove the body class that shows the restrict
        $('body').removeClass('show-leadgengated');
      });
    },
    reset: function () {
      this.local_storage  = JSON.parse(localStorage.getItem(this.local_storage_key));
      this.dismissed_time = (typeof this.local_storage.dismissedTime !== 'undefined') ? this.local_storage.dismissedTime : 0;
    },
    triggerRestrict: function (type) {
      var disable_for = 7*60*60*1000; //1 week
      //var disable_for = 10*1000; //10 seconds (here for testing)

      if(((new Date().getTime() - this.dismissed_time) > disable_for) && !$('body').hasClass('show-leadgengated')) {

        //if the body doesnt have the show-leadgengated trigger an alalytics event
        if(!$('body').hasClass('show-leadgengated')) {
          this.triggerAnalyticsEvent('Lead Generation Gated', type, this.local_storage_key, 1);
        }
        //add a class to the body to show the lean generation popu
        $('body').addClass('show-leadgengated');
      }
    },
    triggerAnalyticsEvent: function (evCat, evAct, evLab, evVal) {
      try {
        ga('send', 'event', evCat, evAct, evLab, evVal);
      } catch (e) {
        console.log(e);
      }
    }
  };
  */

  $(function() {


    $.MTALeadGenGated = function (element) { //renamed arg for readability
      //store the passed element as a property of the created instance.
      this.element = (element instanceof $) ? element : $(element);


      this.access_content_period = 60000; //20 seconds
      //if avaliable, get some information stored in a local variable

      this.access_id      = element.data('access-id');
      this.gated_id      = element.data('gated-id');

      alert(this.gated_id);
      this.local_storage_key  = 'gated_post_'+this.post_id ;
      //console.log('the key: ' + this.local_storage_key);
      //console.log(JSON.parse(localStorage.getItem(this.local_storage_key)));
      //this.local_storage = (JSON.parse(localStorage.getItem(this.local_storage_key)) !== null) ? JSON.parse(localStorage.getItem(this.local_storage_key)) !== null : {}; //gated_post_
      //this.local_storage = (JSON.parse(localStorage.getItem(this.local_storage_key)) !== null) ?  JSON.parse(localStorage.getItem(this.local_storage_key)) !== undefined ? JSON.parse(localStorage.getItem(this.local_storage_key)) : {} : {}; //gated_post_

      this.mtalocalstorage = (localStorage.getItem(this.local_storage_key) !== null) ? localStorage.getItem(this.local_storage_key) !== undefined ? JSON.parse(localStorage.getItem(this.local_storage_key)) : null : null; //gated_post_uuid

      //console.log('the act');
      //console.log(this.mtalocalstorage.ac_t);
      //console.log('the new local storage');
      //console.log(this.local_storage);
      //console.log('the new local this.mtagated_uuid');
      //console.log(this.mtagated_uuid);

      this.time = new Date().getTime();
      this.created   = (this.mtalocalstorage !== null) ? (typeof this.mtalocalstorage.cr_t !== 'undefined') ? this.mtalocalstorage.cr_t : '' : '';
      this.accessed   = (this.mtalocalstorage !== null) ? (typeof this.mtalocalstorage.ac_t !== 'undefined') ? this.mtalocalstorage.ac_t : '' : '';
      this.uuid   = (this.mtalocalstorage !== null) ? (typeof this.mtalocalstorage.mtagated_uuid !== 'undefined') ? this.mtalocalstorage.mtagated_uuid : '' : '';
      //this.last_name    = (this.mtalocalstorage !== null) ? (typeof this.mtalocalstorage.last_name !== 'undefined') ? this.mtalocalstorage.last_name : '' : '';
      //this.company_name = (this.mtalocalstorage !== null) ? (typeof this.mtalocalstorage.company_name !== 'undefined') ? this.mtalocalstorage.company_name : '' : '';

      this.first_name_field      = element.find('.gated-name .name_first input');
      this.last_name_field      = element.find('.gated-name .name_last input');
      this.company_name_field      = element.find('.gated-company input');

      this.ty_display = (element.data('ty-display') !== null) ? (typeof element.data('ty-display') !== 'undefined') ? element.data('ty-display') : 'replace' : 'replace';
      this.gated_id = (element.data('gated-id') !== null) ? (typeof element.data('gated-id') !== 'undefined') ? element.data('gated-id') : 0 : 0;
      this.access_id = (element.data('access-id') !== null) ? (typeof element.data('access-id') !== 'undefined') ? element.data('access-id') : 0 : 0;

       // element.data('data-ty-display');
      //this.last_name      = element.data('post-id');
      //this.company      = element.data('post-id');
      //this.leadgen_trigger    = element.data('leadgen-trigger');
      //this.local_storage_key  = element.data('page-name');
      //this.local_storage      = JSON.parse(localStorage.getItem(this.local_storage_key));
      //this.accessed_time     = (this.local_storage !== null) ? (typeof this.local_storage.accessedTime !== 'undefined') ? this.local_storage.accessedTime : 0 : 0;
    };

    $.MTALeadGenGated.prototype = {

      init: function () {
        //this.date = new Date().getTime();
        //`this` references the instance object inside of an instace's method,
        //however `this` is set to reference a DOM element inside jQuery event
        //handler functions' scope. So we take advantage of JS's lexical scope
        //and assign the `this` reference to another variable that we can access
        //inside the jQuery handlers
        var that = this;
        //var fname = this;
        //var lname = this;
        //var cname = this;


        //Save data when a user successfully submits a gravity form
        $(document).bind('gform_confirmation_loaded', function(event, form_id){
          /*
          ToDo:
          ***make this only do this form gated content forms
          */

          var gatedPost = 'gated_post_'+that.gated_id;
          var gate_post_uuid = that.generate_uuid();
          var object = {gatedPost: gatedPost, uuid: gate_post_uuid, cr_t: that.time, ac_t: that.time};

          /*
          console.log('printing that');
          console.log(that);
          console.log('printing get fname:');
          console.log(fname);
          console.log('printing get lname:');
          console.log(lname);
          console.log('printing get cname:');
          console.log(cname);
          */


          console.log('the object being stored:');
          console.log(object);
          //localStorage.setItem(gatedPost, gate_post_uuid);
          localStorage.setItem(gatedPost, JSON.stringify(object));

          console.log('the stored item');
          console.log(localStorage.getItem(gatedPost));
          that.ajax_display_gated_content(that.gated_id, that.access_id, that.uuid, that.get_fname(), that.get_lname(), that.get_cname(), that.created, that.accessed);

        });

        //console.log(that);
        if(that.accessed !== null && (that.accessed > 0 && ((1*that.access_content_period + 1*that.accessed) > new Date().getTime() ) ) ) {
          //alert('still met');
          that.ajax_display_gated_content();

          /*ToDo update local storage here*/
        }

        //store the first name on blur
        this.first_name_field.bind('keyup', function () {
          that.set_fname(this.value);
        });
        //store the last name on blur
        this.last_name_field.bind('keyup', function () {
          that.set_lname(this.value);
        });
        //store the company name on blur
        this.company_name_field.bind('keyup', function () {
          that.set_cname(this.value);
        });
      },

      get_fname: function() {
        return this.first_name
        return atob(this.first_name);
      },
      get_lname: function() {
        return this.last_name
        //return atob(this.last_name);
      },
      get_cname: function() {
        return this.company_name
        //return atob(this.company_name);
      },
      set_fname: function(value) {
        this.first_name = value;
        //this.first_name = btoa(value);
      },
      set_lname: function(value) {
        this.last_name = value;
        //this.last_name = btoa(value);
      },
      set_cname: function(value) {
        this.company_name = value;

        alert('cname set: ' + this.company_name);
        //this.company_name = btoa(value);
      },
      generate_uuid: function(length, chars){
        length = (length == null) ? 64 : (length >= 64) ? length : 64;
        chars = chars || '#aA';
        var mask = '';
        if (chars.indexOf('a') > -1) mask += 'abcdefghijklmnopqrstuvwxyz';
        if (chars.indexOf('A') > -1) mask += 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
        if (chars.indexOf('#') > -1) mask += '0123456789';
        if (chars.indexOf('!') > -1) mask += '~`!@#$%^&*()_+-={}[]:";\'<>?,./|\\';
        var result = '';
        for (var i = length; i > 0; --i) result += mask[Math.floor(Math.random() * mask.length)];

        return result;
      },


      //that.gated_id, that.access_id, that.uuid, that.created, that.accessed, that.get_fname(), lnathat.get_lname()me, that.get_cname()

      ajax_display_gated_content: function(gated_id, access_id, uuid, fname, lname, cname, created, accessed, addType, delay, html_id ) {


        alert(fname);
        alert(lname);
        alert(cname);
        //alert(fname);
        //`this` references the instance object inside of an instace's method,
        //however `this` is set to reference a DOM element inside jQuery event
        //handler functions' scope. So we take advantage of JS's lexical scope
        //and assign the `this` reference to another variable that we can access
        //inside the jQuery handlers
        var that = this;

        //var gatedPost = 'gated_post_'+that.post_id;
        //var created =(that.created == null) ? that.time : that.created;

        gated_id        = gated_id || 0;
        access_id       = access_id || 0;
        uuid            = uuid    || that.generate_uuid(64, '#aA');
        fname           = fname   || 'Empty FName';
        lname           = lname   || 'Empty LName';
        cname           = cname   || 'Empty CName';
        created         = created   || new Date().getTime();
        accessed        = accessed   || new Date().getTime();
        addType         = addType || 'replace';
        delay           = delay   || 0;
        html_id         = html_id || '#gated_form_wrapper';

        //this.mtagated_uuid = (this.mtagated_uuid !== null) ? thiss.mtagated_uuid !== undefined ? this.mtagated_uuid : uuid : uuid; //gated_post_uuid

        //var gatedPost = 'gated_post_'+that.post_id;
        //var gate_post_uuid = that.generate_uuid();

        //update local storage
        //var object = {gatedPost: gatedPost, uuid: uuid, cr_t: created, ac_t: that.time};
        //localStorage.setItem(gatedPost, JSON.stringify(object));

        setTimeout(function() {
          $.ajax({
            type : "POST",
            dataType : "json",
            url : ajax_object.ajaxurl,
            data : {
              action: "display_gated_content",
              uuid: uuid,
              access_id: access_id,
              gated_id: gated_id,
              fname: fname,
              lname: lname,
              cname: cname,
              accessed: that.accessed,
              created: that.created
            },
            success: function(response) {
              if(response.type == "success") {
                switch(addType) {
                  case 'hide_ty':
                  case 'replace':
                    $(html_id).html(response.data);
                    break;

                  case 'show_ty':
                    $(html_id).append(response.data);

                    break;
                  default:
                    $(html_id).html(response.data);
                    break;
                }
              }
              else {
                console.log('unsuccessful ajax call/response');
                console.log('the response');
                console.log(response);
                console.log('the response type');
                console.log(response.type);
              }
            }
          });
        }, delay);


        //alert('location: ' + pos);
        /*
        $.ajax({
          type : "post",
          dataType : "json",
          url : ajax_object.ajaxurl,
          data : {action: "display_gated_content"},
          success: function(response) {
            if(response.type == "success") {
              $("#gated_form_wrapper").html(response.data);
            }
            else {
              console.log('the response');
              console.log(response);

              console.log('the response type');
              console.log(response.type);
            }
          }
        });
        */
      }
    };

      //if the '#mta_leadgenpopup_wrapper' item exists on the page initialize the exitintent
    if ( $( "#gated_form_wrapper" ).length ) {
      var leadgengated = new $.MTALeadGenGated($("#gated_form_wrapper"));
      leadgengated.init();

    }

    /*
    //if the '#mta_leadgengated_wrapper' item exists on the page initialize the exitintent
    if ( $( "#mta_leadgengated_wrapper" ).length ) {
      var leadgengated = new $.MTAleadgengated($("#mta_leadgengated_wrapper"));
      leadgengated.init();
    }
    */





  });

})( jQuery );
