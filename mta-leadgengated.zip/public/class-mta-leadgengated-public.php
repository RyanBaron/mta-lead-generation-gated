<?php

/**
 * The public-facing functionality of the plugin.
 *
 * @link       http://www.madtownagency.com
 * @since      1.0.0
 *
 * @package    mta_leadgengated
 * @subpackage mta_leadgengated/public
 */

/**
 * The public-facing functionality of the plugin.s
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    mta_leadgengated
 * @subpackage mta_leadgengated/public
 * @author     Ryan Baron <ryan@madtownagency.com>
 */
class Mta_leadgengated_Public {

  /**
   * The ID of this plugin.
   *
   * @since    1.0.0
   * @access   private
   * @var      string    $plugin_name    The ID of this plugin.
   */
  private $plugin_name;

  /**
   * The version of this plugin.
   *
   * @since    1.0.0
   * @access   private
   * @var      string    $version    The current version of this plugin.
   */
  private $version;

  /**
   * Initialize the class and set its properties.
   *
   * @since    1.0.0
   * @param      string    $plugin_name       The name of the plugin.
   * @param      string    $version    The version of this plugin.
   */
  public function __construct( $plugin_name, $version ) {

    $this->plugin_name = $plugin_name;
    $this->version = $version;

    add_action('wp_footer', array($this, 'display_mta_leadgengated_content'), 10, 1);
    add_filter( 'body_class', array($this, 'mta_leadgengated_body_classes' ));

    add_action( 'wp_ajax_display_gated_content', array($this, 'display_gated_content' ) );
    add_action( 'wp_ajax_nopriv_display_gated_content', array($this, 'display_gated_content') );

    //add_action('mta_leadgengated_content', array($this, 'display_mta_leadgengated_content'), 10, 1);
  }

  function get_string_between($string, $start, $end){
    $string = ' ' . $string;
    $ini = strpos($string, $start);
    if ($ini == 0) return '';
    $ini += strlen($start);
    $len = strpos($string, $end, $ini) - $ini;
    return substr($string, $ini, $len);
  }

  /**
   * Extract the gated_content id form the body shortcode body of a post (id passed in)
   *
   * @since   1.0.0
   * @param   string    $id   Post ID.
   *
   * @return  string    $id   The gated content id extracted from the gated_content shortcode in a post body, return 0 if none found
   */
  function extract_gated_content_id($id) {
    $gated_id   = 0;

    //get the post content
    $post_object  = get_post( $id );
    $post_content = $post_object->post_content;

    //get all of the shortcodes in the post body (i.e. content betweeen [])
    preg_match('#\[(.*?)\]#', $post_content, $match);

    foreach($match as $key => $shortcode){
      //normalize all shortcodes to use '
      $shortcode = str_replace('"', '\'', $shortcode);

      //get the correct shortcode
      if (strlen(strstr($shortcode, "gated_id"))>0 && strlen(strstr($shortcode, "mta_gated_content"))>0)
        $gated_id = $this->get_string_between($shortcode, "gated_id='", "'");

      //if we found a match break out of the foreach loop
      if($gated_id)
        break;
    }

    return $gated_id;
  }

  function display_gated_content() {

    global $wpdb;
    //$test = $comma_separated = implode(",", $_POST);
    $uuid = isset($_POST['uuid']) && !empty($_POST['uuid']) ? $_POST['uuid'] : 'empty-uuid'; /* md5(uniqid(rand(), true) ) */
    $created = isset($_POST['created']) && !empty($_POST['created']) ? $_POST['created'] : 'empty-created'; /* md5(uniqid(rand(), true) ) */
    $accessed = isset($_POST['accessed']) && !empty($_POST['accessed']) ? $_POST['accessed'] : 'empty-accessed'; /* md5(uniqid(rand(), true) ) */
    $gated_id = isset($_POST['gated_id']) && !empty($_POST['gated_id']) ? $_POST['gated_id'] : 'empty-gated_id'; /* md5(uniqid(rand(), true) ) */
    $access_id = isset($_POST['access_id']) && !empty($_POST['access_id']) ? $_POST['access_id'] : 'empty-access_id'; /* md5(uniqid(rand(), true) ) */
    //$fname = isset($_POST['fname']) && !empty($_POST['fname']) ? md5($_POST['fname']) : md5('empty-fname'); /* md5(uniqid(rand(), true) ) */
    //$lname = isset($_POST['lname']) && !empty($_POST['lname']) ? md5($_POST['lname']) : md5('empty-lname'); /* md5(uniqid(rand(), true) ) */
    //$cname = isset($_POST['cname']) && !empty($_POST['cname']) ? md5($_POST['cname']) : md5('empty-cname'); /* md5(uniqid(rand(), true) ) */

    $fname = isset($_POST['fname']) && !empty($_POST['fname']) ? $_POST['fname'] : 'empty-fname'; /* md5(uniqid(rand(), true) ) */
    $lname = isset($_POST['lname']) && !empty($_POST['lname']) ? $_POST['lname'] : 'empty-lname'; /* md5(uniqid(rand(), true) ) */
    $cname = isset($_POST['cname']) && !empty($_POST['cname']) ? $_POST['cname'] : 'empty-cname'; /* md5(uniqid(rand(), true) ) */
    $email = isset($_POST['email']) && !empty($_POST['email']) ? $_POST['email'] : 'empty-email'; /* md5(uniqid(rand(), true) ) */
    $phone = isset($_POST['phone']) && !empty($_POST['phone']) ? $_POST['phone'] : 'empty-phone'; /* md5(uniqid(rand(), true) ) */
    //$table_name = $wpdb->prefix . 'mta_leadgen_ut';

    $results = $wpdb->get_results("SELECT count(ID) as total FROM {$wpdb->prefix}mta_leadgen_ut WHERE uuid=%s", $uuid);

    if($results) {

    } else {
      $insert_results = $wpdb->insert(
        "{$wpdb->prefix}mta_leadgen_ut",
        array(
        'uuid' => $uuid,
        'accessed_resources' => json_encode($gated_id),
        'access_id' => $access_id,
        'fname' => $fname,
        'lname' => $lname,
        'company' => $cname,
        'email' => $email,
        'phone' => $phone,
        'created' => $created,
        'lastaccess' => $accessed,
      ),
        array(
        '%s',
        '%s',
        '%s',
        '%s',
        '%s',
        '%s',
        '%s',
        '%s',
        '%s',
        '%s',
        //'%d'
      )
      );
    }

    if($insert_results) {
      $test = "<div><strong>Successful input</strong></div>";
    }
    else {
      $test = "<div><strong>UNSuccessful input</strong></div>";

    }



//$uuidp = 'nothing here now';
    //$uuidp = print_r($_POST);
    $success = 0;
    $url     = wp_get_referer();
    $post_id = url_to_postid( $url );

    $gated_content_id = $this->extract_gated_content_id($post_id);

    if($gated_content_id) {
      $post_object = get_post( $gated_content_id );
      $gated_content = $post_object->post_content;
      $data = "<div class='gated-content'>the insert r2222222222esult as test: $test<br><br><hr><br>the gatedid: $gated_id<br><br>the access id: $access_id<br><br>the uuid: $uuid <br>created: $created <br>accessed: $accessed <br>fname: $fname <br>lname: $lname <br>cname: $cname<br><br><br><br>$gated_content</div>";
      $response = array( 'type' => 'success', 'data' => $data ); //if $data is set
    }
    else {
      $response = array( 'type' => 'fail', 'data' => $gated_content_id ); //if $data is set
    }

    $response = json_encode($response);
    echo $response;
    die();
  }

  /**
   * Register the stylesheets for the public-facing side of the site.
   *
   * @since    1.0.0
   */
  public function enqueue_styles() {

    /**
     * This function is provided for demonstration purposes only.
     *
     * An instance of this class should be passed to the run() function
     * defined in Mta_leadgengated_Loader as all of the hooks are defined
     * in that particular class.
     *
     * The Mta_leadgengated_Loader will then create the relationship
     * between the defined hooks and the functions defined in this
     * class.
     */

    wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/styles.min.css', array(), $this->version, 'all' );

  }

  /**
   * Register the JavaScript for the public-facing side of the site.
   *
   * @since    1.0.0
   */
  public function enqueue_scripts() {

    /**
     * This function is provided for demonstration purposes only.
     *
     * An instance of this class should be passed to the run() function
     * defined in Mta_leadgengated_Loader as all of the hooks are defined
     * in that particular class.
     *
     * The Mta_leadgengated_Loader will then create the relationship
     * between the defined hooks and the functions defined in this
     * class.
     */

    //wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/scripts.min.js', array( 'jquery' ), $this->version, true );
    wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'src/js/scripts.js', array( 'jquery' ), $this->version, true );

    wp_localize_script( $this->plugin_name, 'ajax_object', array( 'ajaxurl' => admin_url( 'admin-ajax.php' )));

  }

  function mta_leadgengated_body_classes( $classes ) {
    if( !isset($post_id) || empty($post_id) )
      $post_id = get_the_ID();

    if( isset($post_id) && !empty($post_id) ) {
      $layout = get_post_meta($post_id, '_mta_leadgengated_layout', true);

      //only add a class if _mta_leadgengated_layout is set
      if(!empty($layout)) {
        $classes[] = 'mta-leadgengated';
      }
    }
    return $classes;
  }

  public function display_mta_leadgengated_content() {
    $content          = '';
    $form             = '';
    $wrapper_classes  = '';

    if( !isset($post_id) || empty($post_id) )
      $post_id = get_the_ID();

    if( isset($post_id) && !empty($post_id) ) {

      $gated_content_id = $this->extract_gated_content_id($post_id);
      $enable_custom  = get_post_meta($post_id, '_mta_leadgengated_enable_custom', true);

      echo "<br><br><br>the gated content id: $gated_content_id<br><br>";

      //if(isset($enable_custom) && $enable_custom == 'custom') {
      /*
      //if mta_leadgengated_enable_custom is set user the meta values from the individual page
        $layout         = get_post_meta($post_id, '_mta_leadgengated_layout', true);
        $trigger        = get_post_meta($post_id, '_mta_leadgengated_trigger', true);
        $timer          = get_post_meta($post_id, '_mta_leadgengated_timer', true);
        $superheadline  = get_post_meta($post_id, '_mta_leadgengated_superheadline', true);
        $headline       = get_post_meta($post_id, '_mta_leadgengated_headline', true);
        $subheadline    = get_post_meta($post_id, '_mta_leadgengated_subheadline', true);
        $text           = get_post_meta($post_id, '_mta_leadgengated_text', true);

        $form_header_align  = get_post_meta($post_id, '_mta_leadgengated_form_header_align', true);
        $form_footer_align  = get_post_meta($post_id, '_mta_leadgengated_form_footer_align', true);
        $form_labels        = get_post_meta($post_id, '_mta_leadgengated_form_labels', true);
        $form_superheadline = get_post_meta($post_id, '_mta_leadgengated_form_superheadline', true);
        $form_headline      = get_post_meta($post_id, '_mta_leadgengated_form_headline', true);
        $form_subheadline   = get_post_meta($post_id, '_mta_leadgengated_form_subheadline', true);
        $form_text          = get_post_meta($post_id, '_mta_leadgengated_form_text', true);
        $gform_id           = get_post_meta($post_id, '_mta_leadgengated_gform_id',true);
      */
      //} else {

      /*
        $default_gated = 0; //assume the page/post is not displaying the restrict

        if(is_page()) {
          //check if this page is selected for display of the default restrict
          $page_display = get_option( 'mta_leadgen_gated_page_display' );
          $default_gated = isset($page_display['mta_leadgen_pages'][$post_id]) ? $page_display['mta_leadgen_pages'][$post_id] : 0;
        } elseif(is_single()) {
          //check if this ppostage is selected for display of the default restrict
          $post_display = get_option( 'mta_leadgen_gated_post_display' );
          $default_gated = isset($post_display['mta_leadgen_posts'][$post_id]) ? $post_display['mta_leadgen_posts'][$post_id] : 0;
        }

*/
        //if($default_gated) {
          //if the page/post is using the default display get the restrict content values
          $default_content = get_option( 'mta_leadgen_gated_content' );

          $layout             = isset($default_content['mta_leadgengated_layout']) ? $default_content['mta_leadgengated_layout'] : '';
      $show_delay            = isset($default_content['mta_leadgengated_show_delay']) ? $default_content['mta_leadgengated_show_delay'] : 1000;
          $timer              = isset($default_content['mta_leadgengated_timer']) ? $default_content['mta_leadgengated_timer'] : '';
          $superheadline      = isset($default_content['mta_leadgengated_superheadline']) ? $default_content['mta_leadgengated_superheadline'] : '';
          $headline           = isset($default_content['mta_leadgengated_headline']) ? $default_content['mta_leadgengated_headline'] : '';
          $subheadline        = isset($default_content['mta_leadgengated_subheadline']) ? $default_content['mta_leadgengated_subheadline'] : '';
          $text               = isset($default_content['mta_leadgengated_text']) ? $default_content['mta_leadgengated_text'] : '';
          $form_header_align  = isset($default_content['mta_leadgengated_form_header_align']) ? $default_content['mta_leadgengated_form_header_align'] : '';
          $form_footer_align  = isset($default_content['mta_leadgengated_form_footer_align']) ? $default_content['mta_leadgengated_form_footer_align'] : '';
          $form_labels        = isset($default_content['mta_leadgengated_form_labels']) ? $default_content['mta_leadgengated_form_labels'] : '';
          $form_superheadline = isset($default_content['mta_leadgengated_form_superheadline']) ? $default_content['mta_leadgengated_form_superheadline'] : '';
          $form_headline      = isset($default_content['mta_leadgengated_form_headline']) ? $default_content['mta_leadgengated_form_headline'] : '';
          $form_subheadline   = isset($default_content['mta_leadgengated_form_subheadline']) ? $default_content['mta_leadgengated_form_subheadline'] : '';
          $form_text          = isset($default_content['mta_leadgengated_form_text']) ? $default_content['mta_leadgengated_form_text'] : '';
          $gform_id           = isset($default_content['mta_leadgengated_gform_id']) ? $default_content['mta_leadgengated_gform_id'] : '';
       // }
      //}



      //bail if the layout is empty
      //if(empty($layout)) {
      //  return false;
      //}

      //get the page name and sanitize it for html
      $page_name = sanitize_html_class(str_replace(" ", "-", strtolower(get_the_title($post_id))), 'default');

      //build our data attributes
      $data_show_delay    = !empty($show_delay) ? " data-show-delay='$show_delay'" : "";
      $data_gated_content_id         = !empty($gated_content_id) ? " data-gated-content='$gated_content_id'" : "";
      //$data_page_name     = !empty($trigger) ? " data-page-name='$page_name'" : "";
      //$data_leadgenclose  = !empty($trigger) ? " data-leadgenclose='$page_name'" : "";

      //build the form headline html
      $form_headline_html  = "";
      $form_headline_html .= !empty($form_superheadline) ? "<span class='superheadline'>$form_superheadline</span>" : "";
      $form_headline_html .= !empty($form_headline) ? $form_headline : "";
      $form_headline_html .= !empty($form_subheadline) ? "<span class='subheadline'>$form_subheadline</span>" : "";
      //wrap the form headline html
      $form_header   = !empty($form_headline_html) ? "<div class='form-header $form_header_align'><h2>$form_headline_html</h2></div>" : "";
      //build the form footer html
      $form_footer = !empty($form_text) ? "<div class='form-footer $form_footer_align'>$form_text</div>" : "";

      //build the content headline html
      $headline_html  = "";
      $headline_html .= !empty($superheadline) ? "<span class='superheadline'>$superheadline</span>" : "";
      $headline_html .= !empty($headline) ? $headline : "";
      $headline_html .= !empty($subheadline) ? "<span class='subheadline'>$subheadline</span>" : "";
      //wrap the content headline html
      $content = !empty($headline_html) ? "<h1>$headline_html</h1>" : "";
      $content = isset($text) ? $content . "<div class='text'>" . $text ."</div>" : $content;

      //build the gravity form
      if(!empty($gform_id)) {
        $form .= do_shortcode('[gravityform id="'.$gform_id.'" name="" title="false" description="false" tabIndex="555" ajax="true"]');
      }

      //generate classes and data attributes
      $classes[] = sanitize_html_class($layout);
      $classes[] = $page_name;
      foreach($classes as $class) {
        $wrapper_classes .= isset($class) && !empty($class) ? ' ' . $class : '';
      }

      //include the template (which uses the above generated variables $content, $form, $wrapper_classes)
      include_once('partials/main-public-display.php');
    }
  }
}
