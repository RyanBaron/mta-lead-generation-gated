<?php

/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              http://www.madtownagency.com
 * @since             1.0.0
 * @package           mta_leadgengated
 *
 * @wordpress-plugin
 * Plugin Name:       MTA Lead Generation Gated
 * Plugin URI:        http://www.madtownagency.com/
 * Description:       This plugin allows admins to hide content on a page that is only displayed after a user fills out a form, granting them access.
 * Version:           1.0.2
 * Author:            Ryan Baron
 * Author URI:        http://www.madtownagency.com
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       mta-leadgengated
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
  die;
}

//define('MTA_LEADGEN_TRACKING_TABLE',  $wpdb->prefix . 'mta_lgut';)
/**
 * The code that runs during plugin activation.
 * This action is documented in includes/class-mta-leadgengated-activator.php
 */
function activate_mta_leadgengated() {
  require_once plugin_dir_path( __FILE__ ) . 'includes/class-mta-leadgengated-activator.php';
  Mta_leadgengated_Activator::activate();
}

/**
 * The code that runs during plugin deactivation.
 * This action is documented in includes/class-mta-leadgengated-deactivator.php
 */
function deactivate_mta_leadgengated() {
  require_once plugin_dir_path( __FILE__ ) . 'includes/class-mta-leadgengated-deactivator.php';
  Mta_leadgengated_Deactivator::deactivate();
}

register_activation_hook( __FILE__, 'activate_mta_leadgengated' );
register_deactivation_hook( __FILE__, 'deactivate_mta_leadgengated' );

/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
require plugin_dir_path( __FILE__ ) . 'includes/class-mta-leadgengated.php';

/**
 * Begins execution of the plugin.
 *
 * Since everything within the plugin is registered via hooks,
 * then kicking off the plugin from this point in the file does
 * not affect the page life cycle.
 *
 * @since    1.0.0
 */
function run_mta_leadgengated() {

  $plugin = new Mta_leadgengated();
  $plugin->run();

}

//https://codex.wordpress.org/Creating_Tables_with_Plugins
register_activation_hook( __FILE__, 'mta_leadgengated_install' );
//register_activation_hook( __FILE__, 'mta_leadgengated_install_data' );

global $mta_leadgengated_db_version;
$mta_leadgengated_db_version = '0.9.0';

function mta_leadgengated_install() {
  global $wpdb;
  global $mta_leadgengated_db_version;

  //echo "<br>the path<br>";
  //print_r(ABSPATH . 'wp-admin/includes/upgrade.php');
  /*
  $table_name = $wpdb->prefix . 'mta_gct';

  $charset_collate = $wpdb->get_charset_collate();

  $sql = "CREATE TABLE $table_name (
    id mediumint(9) NOT NULL AUTO_INCREMENT,
    time datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
    time lastaccess DEFAULT '0000-00-00 00:00:00' NOT NULL,
    fname tinytext NOT NULL,
    lname tinytext NOT NULL,
    company tinytext NOT NULL,
    uuid varchar(100) DEFAULT '' NOT NULL,
    PRIMARY KEY  (id)
  ) $charset_collate;";

  //$upgrade_path = admin_url( 'wp-admin/includes/upgrade.php' );

  //require_once( $upgrade_path );
  require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
  dbDelta( $sql );
  */

  global $wpdb;
  $table_name = $wpdb->prefix . 'mta_leadgen_ut';
  //$table_name = $wpdb->prefix . 'mta_gct1';
  $wpdb_collate = $wpdb->collate;
  $sql =
    "CREATE TABLE {$table_name} (
         id mediumint(8) unsigned NOT NULL auto_increment,
         uuid varchar(255) NOT NULL,
         fname varchar(255) NULL,
         lname varchar(255) NULL,
         company varchar(255) NULL,
         email varchar(255) NULL,
         phone varchar(100) NULL,
         accessed_resources LONGTEXT NULL,
         created datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
         lastaccess datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
         PRIMARY KEY  (id),
         KEY uuid (uuid)
         )
         COLLATE {$wpdb_collate}";

  require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
  dbDelta( $sql );

  //add_option( 'mta_leadgengated_db_version', $mta_leadgengated_db_version );
}

/*
function mta_leadgengated_install_data() {
  global $wpdb;

  $welcome_name = 'Mr. WordPress';
  $welcome_text = 'Congratulations, you just completed the installation!';

  $table_name = $wpdb->prefix . 'liveshoutbox';

  $wpdb->insert(
    $table_name,
    array(
    'time' => current_time( 'mysql' ),
    'name' => $welcome_name,
    'text' => $welcome_text,
  )
  );
}
*/

run_mta_leadgengated();
