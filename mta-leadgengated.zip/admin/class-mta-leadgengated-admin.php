<?php

/**
 * The admin-specific functionality of the plugin.
 *
 * @link       http://www.madtownagency.com
 * @since      1.0.0
 *
 * @package    Mta_Gated_Content
 * @subpackage Mta_Gated_Content/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Mta_Gated_Content
 * @subpackage Mta_Gated_Content/admin
 * @author     Ryan Baron <ryan@madtownagency.com>
 */
class Mta_LeadGen_Gated_Content_Admin {

  /**
   * The ID of this plugin.
   *
   * @since    1.0.0
   * @access   private
   * @var      string    $plugin_name    The ID of this plugin.
   */
  private $plugin_name;

  /**
   * The version of this plugin.
   *
   * @since    1.0.0
   * @access   private
   * @var      string    $version    The current version of this plugin.
   */
  private $version;

  /**
   * Initialize the class and set its properties.
   *
   * @since    1.0.0
   * @param      string    $plugin_name       The name of this plugin.
   * @param      string    $version    The version of this plugin.
   */
  public function __construct( $plugin_name, $version ) {

    $this->plugin_name = $plugin_name;
    $this->version = $version;

    add_action( 'admin_menu', array( $this, 'add_mta_leadgen_gated_content_admin_page' ) );
    add_action( 'admin_init', array( $this, 'page_init' ) );

    add_action('init', array($this, 'mta_gated_content_post_type'));



    add_shortcode( 'mta_gated_content', array($this, 'mta_gated_content_function') );

    //add_action('add_meta_boxes', array($this, 'mta_gated_content_metabox'));
    //add_action('save_post', array($this, 'save'));
    add_action('save_post', array($this, 'save_gated_content_post'));
    add_action( 'add_meta_boxes', array($this, 'mta_gated_content_post_metabox_add') );


    add_filter( 'gform_field_value_gated_content', array($this, 'gated_content_population_function' ) );
    //add_filter( 'gform_confirmation', array($this, 'gated_content_confirmation'), 10, 4  );

    add_filter( 'gform_confirmation_anchor', array($this, 'gated_content_confirmation_anchor_function') );

    //add_action( 'admin_footer',  array($this, 'my_action_javascript' ) ); // Write our JS below here


    add_action( 'template_include', array($this, 'mta_gated_content_redirect_post' ) );



  }


  function my_callback( $original_template ) {
    if ( some_condition() ) {
      return SOME_PATH . '/some-custom-file.php';
    } else {
      return $original_template;
    }
  }

  function mta_gated_content_redirect_post($original_template) {

    $is_admin = current_user_can( 'manage_options' );
    $queried_post_type = get_query_var('post_type');

    if ( is_single() && 'gated_content' == $queried_post_type && $is_admin) {

      $redirect_url = '#redirect';

      printf( __('You are seeing this page because you have an admin role, regular users would be redirected to the <a href="%1$s">[get redirect url]</a> page.', 'mta-leadgenpopup'), $redirect_url );


      return $original_template;
    }
    elseif ( is_single() && 'gated_content' ==  $queried_post_type && !$is_admin) {
      wp_redirect( home_url(), 301 );
      //exit();
    }

    return $original_template;

  }


  /**
   * The options select field values
   *
   * @since   1.0.2
   * @param   string    $type     The select field values are needed for
   *
   * return   an array of select field options
   */
  public function get_select_values($type) {
    switch($type) {
      case 'thank_you_display':

        return array(
          'hide_ty'    => __("Hide (Hide form thank you after submit)",                   'mta-leadgenpopup'),
          'show_ty'   => __('Show (Show form thank you after submit)',            'mta-leadgenpopup'),
        );
        break;
      case 'access_period':
        return array(
          '0'    => __('1 Time',     'mta-leadgenpopup'),
          'session'    => __('Session (Until the user closes the browser.)',     'mta-leadgenpopup'),
          '60000'    => __('1 min',     'mta-leadgenpopup'),
          '600000'    => __('10 min',     'mta-leadgenpopup'),
          '3600000'    => __('1 hr',     'mta-leadgenpopup'),
          '14400000'    => __('4 hr',     'mta-leadgenpopup'),
          '21600000'    => __('6 hr',     'mta-leadgenpopup'),
          '28800000'    => __('8 hr',     'mta-leadgenpopup'),
          '36000000'    => __('10 hr',     'mta-leadgenpopup'),
          '43200000'    => __('12 hr',     'mta-leadgenpopup'),
          '64800000'    => __('18 hr',     'mta-leadgenpopup'),
          '86400000'    => __('1 Day',     'mta-leadgenpopup'),
          '864000000'    => __('10 Days',    'mta-leadgenpopup'),
          '17280000000'   => __('20 Days',   'mta-leadgenpopup'),
          '25920000000'   => __('30 Days',   'mta-leadgenpopup'),
          '51840000000'   => __('60 Days',   'mta-leadgenpopup'),
          '77760000000'   => __('90 Days',   'mta-leadgenpopup'),
        );
        break;

    }
    return array();
  }

  function gated_content_confirmation_anchor_function() {
    return false;
  }

  /*
  function gated_content_confirmation( $confirmation, $form, $entry, $ajax ) {

    if(is_array($entry)) {
      foreach($entry as $key => $value){


        //$confirmation .= "<br><br> " .substr( $value, 0, 13 ) ."<br>";
        if(substr( $value, 0, 14 ) === "gated_content_") {

          $pieces = explode("_", $value);

          //$confirmation .= "<br><br><br>Found the sub string<br><br>";
          //$confirmation .= print_r($pieces);

          //$confirmation .= "the content to load: " . $pieces[2];

          $post_id = $pieces[2];
          $post_object = get_post( $post_id );
          $confirmation = '<div>' . $post_object->post_content . '</div>';

          //$confirmation .= "<br><br><br>Found the sub string<br><br>";
        }
      }
    }
    //$confirmation = "<br><br>The form".print_r($form);
    //$confirmation = "<br>The Entry<br><br>" .print_r($entry) ."<br><br>";

    //if( $form['id'] == '101' ) {
    //  $confirmation = array( 'redirect' => 'http://www.google.com' );
    //} elseif( $form['id'] == '102' ) {
    //  $confirmation = "Thanks for contacting us. We will get in touch with you soon";
    //}

    //$confirmation .= "<br><br>Some new confirmation stuff here<br><br>";
    return $confirmation;
  }
  */

  function gated_content_population_function( $value ) {
    return 'gated_content_'.$value;
  }

  function mta_gated_content_function( $atts ){

    global $post;

    $id = isset($atts['gated_id']) && !empty($atts['gated_id']) ? $atts['gated_id'] : 0;

    //if the shortcode does not have a gated id, let the admin user know
    if(!$id) {
      if ( is_admin() ) {
        $ret = "<div>The shortcode requires a valid 'gated_id' attribute.</div>";
      }
    }

    $gated_post = get_post( $id );

    if(!isset($gated_post) || empty($gated_post)) {
      if ( is_admin() ) {
        $ret = "<div>The post id: $id is not a valid post id.</div>";
        return $ret;
      }
    }

    $post_type = $gated_post->post_type;

    //echo "Post type: $post_type";
    if($post_type != 'gated_content') {
      if ( is_admin() ) {
        $ret = "<div>Sorry, the post id: $id is not a 'Gated Content' Post.</div>";
        return $ret;
      }
    }


    $gform_id     = get_post_meta($id, '_mta_leadgen_gated_gform_id', true);
    $ty_display     = get_post_meta($id, '_mta_leadgen_gated_ty_display', true);
    //echo "<br>the form id: $gform_id<br>";
    $gform_exists = GFAPI::form_id_exists($gform_id);
    //$forms = RGFormsModel::get_forms( null, 'title' );
    if(!$gform_exists) {
      if ( is_admin() ) {
        $ret = "<div>Sorry, the gravity form with the id: $gform_id is not a valid form.</div>";
        return $ret;
      }
    }

    //all items have passed validation, show the form on the page.
    //valid post, valid gated_contnet post, gravity form selected on the gated content page is valid


    //$ret .= do_shortcode('[gravityform id="'.$id.'" name="" title="false" description="false" tabIndex="555" ajax="true"]');


    //$this-> extract_gated_content_id()
    //echo $gform_id."<br>the id above";
    //$ret = GFAPI::get_form($gform_id);
    //$form = GFAPI::get_form( $gform_id );
    //$display_title, $display_description, $force_display, $field_values, $ajax, $tabindex
    $ret = GFFormDisplay::get_form($gform_id, false, false, false, array('gated_content' => $id), true, 999);

    $ret = '<div id="gated_form_wrapper" class="'.$ty_display.'" data-ty-display="'.$ty_display.'" data-gated-id="'.$id.'" data-access-id="'.$post->ID.'">'.$ret.'</div>';
    //print_r($form);
    //$ret = GFFormsModel::get_form($gform_id);



    return $ret;
  }


/*
  function get_string_between($string, $start, $end){
    $string = ' ' . $string;
    $ini = strpos($string, $start);
    if ($ini == 0) return '';
    $ini += strlen($start);
    $len = strpos($string, $end, $ini) - $ini;
    return substr($string, $ini, $len);
  }
*/
  /**
   * Extract the gated_content id form the body shortcode body of a post (id passed in)
   *
   * @since   1.0.0
   * @param   string    $id   Post ID.
   *
   * @return  string    $id   The gated content id extracted from the gated_content shortcode in a post body, return 0 if none found
   */
  /*
  function extract_gated_content_id($id) {
    $gated_id   = 0;

    //get the post content
    $post_object  = get_post( $id );
    $post_content = $post_object->post_content;

    //get all of the shortcodes in the post body (i.e. content betweeen [])
    preg_match('#\[(.*?)\]#', $post_content, $match);

    foreach($match as $key => $shortcode){
      //normalize all shortcodes to use '
      $shortcode = str_replace('"', '\'', $shortcode);

      //get the correct shortcode
      if (strlen(strstr($shortcode, "gated_id"))>0 && strlen(strstr($shortcode, "mta_gated_content"))>0)
        $gated_id = $this->get_string_between($shortcode, "gated_id='", "'");

      //if we found a match break out of the foreach loop
      if($gated_id)
        break;
    }

    return $gated_id;
  }
*/

  /**
   * Adding an plugin options page
   *
   * @since   1.0.0
   *
   */
  public function add_mta_leadgen_gated_content_admin_page() {
    //Add a new top level Lead Generation Gated Page
    add_menu_page(
      'Lead Generation Gated Content Options',
      'Gated Content',
      'manage_options',
      'mta-gated-content',
      array( $this, 'create_gated_content_admin_page' )
    );

    add_submenu_page( 'mta-gated-content', 'Gated Items', 'Gated Content Items',  'manage_options', 'edit.php?post_type=gated_content', NULL );
  }

  /**
   * Options page callback
   *
   * @since   1.0.2
   *
   */
  public function create_gated_content_admin_page() {
    $this->gated_content_options = get_option( 'mta_leadgen_gated_content' );
?>
<div class="wrap mta-leadgengated-options-page">
  <h1><?php _e("Lead Generation Gated Content Options", "mta-leadgengated"); ?></h1>
  <form method="post" action="options.php">
    <?php
    settings_fields( 'mta_leadgen_gated_content_group' );
    do_settings_sections( 'mta-leadgen-gated-settings' );
    ?>
  </form>
</div>
<?php }


  public function mta_gated_content_post_metabox_add($post_type) {
    //$post_types = array('post', 'page');
    $post_types = array('gated_content');

    //limit meta box to certain post types
    if (in_array($post_type, $post_types)) {

      add_meta_box('mta-gated_content',
                   'Resource Options',
                   array($this, 'mta_gated_content_post_meta_box_function'),
                   $post_type,
                   'normal',
                   'high');

    }
  }


  /**
   * Register and add settings
   *
   * @since   1.0.0
   *
   */
  public function page_init() {
    //////
    // Register mta leadgen gated content settings
    //////
    register_setting(
      'mta_leadgen_gated_content_group', // Option group
      'mta_leadgen_gated_content', // Option name
      array( $this, 'sanitize_content' ) // Sanitize
    );
    //////
    // Create the mta leadgen gated content settings section
    /////
    add_settings_section(
      'gated_settings', // ID
      'Default Gated Settings', // Title
      array( $this, 'print_settings_section_info' ), // Callback
      'mta-leadgen-gated-settings' // Page
    );
    //////
    // Add the mta leadgen gated setting fields
    //////


    add_settings_field(
      'mta_leadgengated_layout', // ID
      'Gated Layout', // Title
      array( $this, 'select_layout_callback' ), // Callback
      'mta-leadgen-gated-settings', // Page
      'gated_settings' // Section
    );

    }
  /**
   * Adds the meta box container.
   */
  public function mta_gated_content_metabox($post_type) {
    $post_types = array('page');

    //limit meta box to certain post types
    if (in_array($post_type, $post_types)) {
      $post_id = isset($_POST['post_ID']) && is_numeric($_POST['post_ID']) && !empty($_POST['post_ID']) ? $_POST['post_ID'] : 0;
      $post_id = isset($_GET['post']) && is_numeric($_GET['post']) && !empty($_GET['post']) ? $_GET['post'] : $post_id;

      //limit meta box to certain template files. (only updates on load/reload)
      if($post_id) {
        $template_file = get_post_meta($post_id,'_wp_page_template',TRUE);
        switch($template_file) {
          case 'template-home.php':
            add_meta_box('page-gated_content-content',
                         'Page - Gated Content Content',
                         array($this, 'mta_gated_content_metabox_function'),
                         $post_type,
                         'normal',
                         'core');
            break;
        }
      }
    }
  }


  public function mta_gated_content_post_meta_box_function($post) {

    $post_id = $post->ID;

    echo "<div><h3>Use this gated content on a page.</h3></div>";
    echo "<div class='meta-item'><strong>[mta_gated_content gated_id='$post_id']</strong></div>";

    wp_nonce_field('mta_gated_content_post_nonce_check', 'mta_gated_content_post_nonce_check_value');
    $mta_leadgen_gated_gform_id               = get_post_meta($post->ID, '_mta_leadgen_gated_gform_id', true);
    $mta_leadgen_gated_ty_display             = get_post_meta($post->ID, '_mta_leadgen_gated_ty_display', true);
    $mta_leadgen_gated_access_period          = get_post_meta($post->ID, '_mta_leadgen_gated_access_period', true);

    $form_items = [];
    $forms = RGFormsModel::get_forms( null, 'title' );
    if(is_array($forms) && !empty($forms)) {

      $form_select = '<select name="mta_leadgen_gated_gform_id" id="mta_leadgen_gated_gform_id">';
      $form_select .= '<option id="">None</option>';
      $forms = RGFormsModel::get_forms( null, 'title' );
      foreach( $forms as $form ):
        $form_select .= '<option value="' . $form->id . '" ' . selected( $mta_leadgen_gated_gform_id, $form->id, false ) .' >' . $form->title . '</option>';
      endforeach;
      $form_select .= '</select>';
      $form_select = '<label for="mta_leadgen_gated_gform_id">'. __('Select Popup Gravity Form', 'mta-leadgenpopup') .' ' . $form_select .'</label>';

      $form_items['form_select'] = array(
        'wrapper_class' => 'meta-input',
        'field_item' => $form_select,
      );
    }

    $ty_options = $this->get_select_values('thank_you_display');
    if(is_array($ty_options) && !empty($ty_options)) {
      $ty_display_select = '<select name="mta_leadgen_gated_ty_display" id="mta_leadgen_gated_ty_display">';
      foreach( $ty_options as $value => $label ):
      $ty_display_select .= '<option value="' . $value . '" ' . selected( $mta_leadgen_gated_ty_display, $value, false ) .' >' . $label . '</option>';
      endforeach;
      $ty_display_select .= '</select>';
      $ty_display_select = '<label for="mta_leadgen_gated_ty_display">'.__('Display the thank you mesage upon successful for submission.', 'mta-leadgenpopup') .' ' . $ty_display_select .'</label>';

      $form_items['ty_display_select'] = array(
        'wrapper_class' => 'meta-input',
        'field_item' => $ty_display_select,
      );
    }
    $access_period = $this->get_select_values('access_period');
    if(is_array($access_period) && !empty($access_period)) {
      $access_period_select = '<select name="mta_leadgen_gated_access_period" id="mta_leadgen_gated_access_period">';
      foreach( $access_period as $value => $label ):
      $access_period_select .= '<option value="' . $value . '" ' . selected( $mta_leadgen_gated_access_period, $value, false ) .' >' . $label . '</option>';
      endforeach;
      $access_period_select .= '</select>';
      $access_period_select = '<label for="mta_leadgen_gated_access_period">'.__('Select how long the user has access to the gated content for.', 'mta-leadgenpopup') .' ' . $access_period_select .'</label>';

      $form_items['access_period_select'] = array(
        'wrapper_class' => 'meta-input',
        'field_item' => $access_period_select,
        'field_desc' => __('<div class="description">Select the period of time the user should get access to the gated content for.  This data is saved as local storage data data.</div>','mta-leadgenpopup')
      );
    }
    $tracking = $this->get_select_values('prospect_tracking');
    if(is_array($access_period) && !empty($access_period)) {
      $access_period_select = '<select name="mta_leadgen_gated_access_period" id="mta_leadgen_gated_access_period">';
      foreach( $access_period as $value => $label ):
      $access_period_select .= '<option value="' . $value . '" ' . selected( $mta_leadgen_gated_access_period, $value, false ) .' >' . $label . '</option>';
      endforeach;
      $access_period_select .= '</select>';
      $access_period_select = '<label for="mta_leadgen_gated_access_period">'.__('Select how long the user has access to the gated content for.', 'mta-leadgenpopup') .' ' . $access_period_select .'</label>';

      $form_items['access_period_select'] = array(
        'wrapper_class' => 'meta-input',
        'field_item' => $access_period_select,
        'field_desc' => __('<div class="description">* This data is saved as local storage data on the users computer. ','mta-leadgenpopup')
      );
    }





  //include the template (which uses the above generated variables $content, $form, $wrapper_classes)
  include_once('partials/gated-content-meta-box-display.php');

    /*
    $gated_content_intro_text               = get_post_meta($post->ID, 'gated_content_intro_text', true);
    $gated_content_logo                     = get_post_meta($post->ID, 'gated_content_logo', true);
    $gated_content_screen_shot              = get_post_meta($post->ID, 'gated_content_screen_shot', true);
    $gated_content_main_content_headline    = get_post_meta($post->ID, 'gated_content_main_content_headline', true);
    $gated_content_main_content_top_text    = get_post_meta($post->ID, 'gated_content_main_content_top_text', true);
    $gated_content_main_content_quote       = get_post_meta($post->ID, 'gated_content_main_content_quote', true);
    $gated_content_main_content_bottom_text = get_post_meta($post->ID, 'gated_content_main_content_bottom_text', true);
    $gated_content_customer_quote           = get_post_meta($post->ID, 'gated_content_customer_quote', true);
    $gated_content_customer_quote_name      = get_post_meta($post->ID, 'gated_content_customer_quote_name', true);
    $gated_content_customer_quote_name_info = get_post_meta($post->ID, 'gated_content_customer_quote_name_info', true);
    $carousel_headline                  = get_post_meta($post->ID, 'carousel_headline', true);
    $carousel_top_text                  = get_post_meta($post->ID, 'carousel_top_text', true);

    $carousel_img_1 = get_post_meta($post->ID, 'carousel_img_1', true);
    $carousel_img_2 = get_post_meta($post->ID, 'carousel_img_2', true);
    $carousel_img_3 = get_post_meta($post->ID, 'carousel_img_3', true);
    $carousel_img_4 = get_post_meta($post->ID, 'carousel_img_4', true);
    $carousel_img_5 = get_post_meta($post->ID, 'carousel_img_5', true);
    $carousel_img_6 = get_post_meta($post->ID, 'carousel_img_6', true);
    $carousel_img_7 = get_post_meta($post->ID, 'carousel_img_7', true);
    $carousel_img_8 = get_post_meta($post->ID, 'carousel_img_8', true);

    $gated_content_results_super_headline     = get_post_meta($post->ID, 'gated_content_results_super_headline', true);
    $gated_content_results_headline           = get_post_meta($post->ID, 'gated_content_results_headline', true);
    $gated_content_results_top_text           = get_post_meta($post->ID, 'gated_content_results_top_text', true);
    $gated_content_results_number_one         = get_post_meta($post->ID, 'gated_content_results_number_one', true);
    $gated_content_results_number_one_text    = get_post_meta($post->ID, 'gated_content_results_number_one_text', true);
    $gated_content_results_number_two         = get_post_meta($post->ID, 'gated_content_results_number_two', true);
    $gated_content_results_number_two_text    = get_post_meta($post->ID, 'gated_content_results_number_two_text', true);
    $gated_content_results_number_three       = get_post_meta($post->ID, 'gated_content_results_number_three', true);
    $gated_content_results_number_three_text  = get_post_meta($post->ID, 'gated_content_results_number_three_text', true);
    $gated_content_results_url                = get_post_meta($post->ID, '$gated_content_results_url', true);

    echo '<div class="bootstrap-wrapper">';
    echo '<div class="container-fluid">';
    echo '<div class="row">';
    echo '<div class="col-md-12">';

?>
<div class="meta-input">
  <h2>Header Content Options</h2>
  <div class="meta-input">
    <label for="gated_content_logo">Logo Image</label>
    <input type="text" class="gated_content_logo" name="gated_content_logo" id="gated_content_logo" value="<?php echo $gated_content_logo; ?>" />
    <div class="description">Image Size - 300px by 300px</div>
    <input id="Image_button" class="upload-button" name="gated_content_logo" type="button" value="Upload Image" />
  </div>
  <div class="meta-input">
    <label for="gated_content_intro_text">Gated Content Intro Text</label>
    <textarea name="gated_content_intro_text" id="gated_content_intro_text"><?php echo $gated_content_intro_text; ?></textarea>
  </div>
  <div class="meta-input">
    <label for="gated_content_screen_shot">Screen Shot Image</label>
    <input type="text" class="gated_content_screen_shot" name="gated_content_screen_shot" id="gated_content_screen_shot" value="<?php echo $gated_content_screen_shot; ?>" />
    <div class="description">Website Screen Shot Image</div>
    <input id="Image_button" class="upload-button" name="gated_content_screen_shot" type="button" value="Upload Image" />
  </div>

  <h2>Main Content Options</h2>
  <div class="meta-input">
    <label for="gated_content_main_content_headline">Main Content Headline</label>
    <input name="gated_content_main_content_headline" id="gated_content_main_content_headline" value="<?php echo $gated_content_main_content_headline; ?>" />
  </div>
  <div class="meta-input">
    <label for="gated_content_main_content_top_text">Main Content Top Text</label>
    <textarea name="gated_content_main_content_top_text" id="gated_content_main_content_top_text"><?php echo $gated_content_main_content_top_text; ?></textarea>
  </div>
  <div class="meta-input">
    <label for="gated_content_main_content_quote">Main Content Quote</label>
    <textarea name="gated_content_main_content_quote" id="gated_content_main_content_quote"><?php echo $gated_content_main_content_quote; ?></textarea>
  </div>
  <div class="meta-input">
    <label for="gated_content_main_content_bottom_text">Main Content Bottom Text</label>
    <textarea name="gated_content_main_content_bottom_text" id="gated_content_main_content_bottom_text"><?php echo $gated_content_main_content_bottom_text; ?></textarea>
  </div>

  <h2>Customer Quote Content Options</h2>
  <div class="meta-input">
    <label for="gated_content_customer_quote">Customer Quote</label>
    <textarea name="gated_content_customer_quote" id="gated_content_customer_quote"><?php echo $gated_content_customer_quote; ?></textarea>
  </div>
  <div class="meta-input">
    <label for="gated_content_customer_quote_name">Customer Quote Name</label>
    <input name="gated_content_customer_quote_name" id="gated_content_customer_quote_name" value="<?php echo $gated_content_customer_quote_name; ?>" />
  </div>
  <div class="meta-input">
    <label for="gated_content_customer_quote_name_info">Customer Quote Position/Company</label>
    <input name="gated_content_customer_quote_name_info" id="gated_content_customer_quote_name_info" value="<?php echo $gated_content_customer_quote_name_info; ?>" />
  </div>

  <h2>Slider Content Options</h2>
  <div class="meta-input">
    <label for="carousel_headline">Slider Content Headline</label>
    <input name="carousel_headline" id="carousel_headline" value="<?php echo $carousel_headline; ?>" />
  </div>

  <div class="meta-input">
    <label for="carousel_top_text">Main Content Text</label>
    <textarea name="carousel_top_text" id="carousel_top_text"><?php echo $carousel_top_text; ?></textarea>
  </div>

  <div class="meta-input">
    <label for="carousel_img_1">Screen Shot Image</label>
    <input type="text" class="carousel_img_1" name="carousel_img_1" id="carousel_img_1" value="<?php echo $carousel_img_1; ?>" />
    <div class="description">Website Screen Shot Image</div>
    <input id="Image_button" class="upload-button" name="carousel_img_1" type="button" value="Upload Image" />
  </div>
  <div class="meta-input">
    <label for="carousel_img_2">Screen Shot Image</label>
    <input type="text" class="carousel_img_2" name="carousel_img_2" id="carousel_img_2" value="<?php echo $carousel_img_2; ?>" />
    <div class="description">Website Screen Shot Image</div>
    <input id="Image_button" class="upload-button" name="carousel_img_2" type="button" value="Upload Image" />
  </div>
  <div class="meta-input">
    <label for="carousel_img_3">Screen Shot Image</label>
    <input type="text" class="carousel_img_3" name="carousel_img_3" id="carousel_img_3" value="<?php echo $carousel_img_3; ?>" />
    <div class="description">Website Screen Shot Image</div>
    <input id="Image_button" class="upload-button" name="carousel_img_3" type="button" value="Upload Image" />
  </div>
  <div class="meta-input">
    <label for="carousel_img_4">Screen Shot Image</label>
    <input type="text" class="carousel_img_4" name="carousel_img_4" id="carousel_img_4" value="<?php echo $carousel_img_4; ?>" />
    <div class="description">Website Screen Shot Image</div>
    <input id="Image_button" class="upload-button" name="carousel_img_4" type="button" value="Upload Image" />
  </div>
  <div class="meta-input">
    <label for="carousel_img_5">Screen Shot Image</label>
    <input type="text" class="carousel_img_5" name="carousel_img_5" id="carousel_img_5" value="<?php echo $carousel_img_5; ?>" />
    <div class="description">Website Screen Shot Image</div>
    <input id="Image_button" class="upload-button" name="carousel_img_5" type="button" value="Upload Image" />
  </div>
  <div class="meta-input">
    <label for="carousel_img_6">Screen Shot Image</label>
    <input type="text" class="carousel_img_6" name="carousel_img_6" id="carousel_img_6" value="<?php echo $carousel_img_6; ?>" />
    <div class="description">Website Screen Shot Image</div>
    <input id="Image_button" class="upload-button" name="carousel_img_6" type="button" value="Upload Image" />
  </div>
  <div class="meta-input">
    <label for="carousel_img_7">Screen Shot Image</label>
    <input type="text" class="carousel_img_7" name="carousel_img_7" id="carousel_img_7" value="<?php echo $carousel_img_7; ?>" />
    <div class="description">Website Screen Shot Image</div>
    <input id="Image_button" class="upload-button" name="carousel_img_7" type="button" value="Upload Image" />
  </div>
  <div class="meta-input">
    <label for="carousel_img_8">Screen Shot Image</label>
    <input type="text" class="carousel_img_1" name="carousel_img_8" id="carousel_img_8" value="<?php echo $carousel_img_8; ?>" />
    <div class="description">Website Screen Shot Image</div>
    <input id="Image_button" class="upload-button" name="carousel_img_8" type="button" value="Upload Image" />
  </div>

  <h2>Results Section</h2>
  <div class="meta-input">
    <label for="gated_content_results_super_headline">Results Section Super Headline</label>
    <input name="gated_content_results_super_headline" id="gated_content_results_super_headline" value="<?php echo $gated_content_results_super_headline; ?>" />
  </div>
  <div class="meta-input">
    <label for="gated_content_results_headline">Results Section Headline</label>
    <input name="gated_content_results_headline" id="gated_content_results_headline" value="<?php echo $gated_content_results_headline; ?>" />
  </div>
  <div class="meta-input">
    <label for="gated_content_results_top_text">Results Section Top Text</label>
    <textarea name="gated_content_results_top_text" id="gated_content_results_top_text"><?php echo $gated_content_results_top_text; ?></textarea>
  </div>
  <div class="meta-input">
    <label for="gated_content_results_number_one">Results Number 1</label>
    <input name="gated_content_results_number_one" id="gated_content_results_number_one" value="<?php echo $gated_content_results_number_one; ?>" />
  </div>
  <div class="meta-input">
    <label for="gated_content_results_number_one_text">Results Number 1 Text</label>
    <input name="gated_content_results_number_one_text" id="gated_content_results_number_one_text" value="<?php echo $gated_content_results_number_one_text; ?>" />
  </div>
  <div class="meta-input">
    <label for="gated_content_results_number_two">Results Number 2</label>
    <input name="gated_content_results_number_two" id="gated_content_results_number_two" value="<?php echo $gated_content_results_number_two; ?>" />
  </div>
  <div class="meta-input">
    <label for="gated_content_results_number_two_text">Results Number 2 Text</label>
    <input name="gated_content_results_number_two_text" id="gated_content_results_number_two_text" value="<?php echo $gated_content_results_number_two_text; ?>" />
  </div>
  <div class="meta-input">
    <label for="gated_content_results_number_three">Results Number 3</label>
    <input name="gated_content_results_number_three" id="gated_content_results_number_three" value="<?php echo $gated_content_results_number_three; ?>" />
  </div>
  <div class="meta-input">
    <label for="gated_content_results_number_three_text">Results Number 3 Text</label>
    <input name="gated_content_results_number_three_text" id="gated_content_results_number_three_text" value="<?php echo $gated_content_results_number_three_text; ?>" />
  </div>
  <div class="meta-input">
    <label for="gated_content_results_url">Results Project URL</label>
    <input name="gated_content_results_url" id="gated_content_results_url" value="<?php echo $gated_content_results_url; ?>" />
  </div>
</div>

<?php

    echo '</div>';
    echo '</div>';
    echo '</div>';
    echo '</div>';
    */
  }


  public function mta_gated_content_metabox_function($post) {

    // Add an nonce field so we can check for it later.
    wp_nonce_field('mta_gated_content_nonce_check', 'mta_gated_content_nonce_check_value');

    /*
    // Use get_post_meta to retrieve an existing value from the database.
    $header_style_top = get_post_meta($post->ID, '_mta_page_gated_content_content_header_style_top', true);
    $header_style_btm = get_post_meta($post->ID, '_mta_page_gated_content_content_header_style_btm', true);
    $header_bg        = get_post_meta($post->ID, '_mta_page_gated_content_content_header_bg', true);
    $header_position  = get_post_meta($post->ID, '_mta_page_gated_content_content_header_position', true);
    $superheadline    = get_post_meta($post->ID, '_mta_page_gated_content_content_superheadline', true);
    $headline         = get_post_meta($post->ID, '_mta_page_gated_content_content_headline', true);
    $subheadline      = get_post_meta($post->ID, '_mta_page_gated_content_content_subheadline', true);
    $text             = get_post_meta($post->ID, '_mta_page_gated_content_content_text', true);
    $gated_content_display_tax = get_post_meta($post->ID, 'mta_page_gated_content_content_svcs_display_tax', true);
    //$link_url         = get_post_meta($post->ID, '_mta_page_gated_content_content_link_url', true);
    //$link_text        = get_post_meta($post->ID, '_mta_page_gated_content_content_link_text', true);
    //$content_style    = get_post_meta($post->ID, '_mta_page_gated_content_content_style', true);
    //$bg_image         = get_post_meta($post->ID, '_mta_page_gated_content_content_bg', true);

    $content_taxonomy_markup = '';
    $args = array();
    $gated_content_taxonomy_markup = getGatedContentTaxonomySelect('gated_content_display_cat', $args, $gated_content_display_tax, 'mta_page_gated_content_content_svcs_display_tax', 'medium', 'mta_page_gated_content_content_svcs_display_tax', 'Select Resource Content Taxonomy', FALSE);

    echo '<div class="bootstrap-wrapper">';
    echo '<div class="container-fluid">';
    echo '<div class="row">';
    echo '<div class="col-md-12">';
    echo '<div><h3>Section Header</h3></div>';
    echo '<div class="meta-input">';
    echo '<label for="mta_page_gated_content_content_header_style_top">';
    echo '<strong><p>Select the top display style for the section header.</p></strong>';
    echo '</label>';
    echo '<select name="mta_page_gated_content_content_header_style_top" id="mta_page_gated_content_content_header_style_top">';
    echo '<option value="" '. selected( $header_style_top, "" ) . '>None</option>';
    echo '<option value="top-angle-left" '. selected( $header_style_top, "top-angle-left" ) . '>Top Angle Left</option>';
    echo '<option value="top-angle-right" '. selected( $header_style_top, "top-angle-right" ) . '>Top Angle Right</option>';
    echo '</select>';
    echo '</div>';

    echo '<div class="meta-input">';
    echo '<label for="mta_page_gated_content_content_header_style_btm">';
    echo '<strong><p>Select the bottom display style for section header.</p></strong>';
    echo '</label>';
    echo '<select name="mta_page_gated_content_content_header_style_btm" id="mta_page_gated_content_content_header_style_btm">';
    echo '<option value="" '. selected( $header_style_btm, "" ) . '>None</option>';
    echo '<option value="bottom-angle-left" '. selected( $header_style_btm, "bottom-angle-left" ) . '>Bottom Angle Left</option>';
    echo '<option value="bottom-angle-right" '. selected( $header_style_btm, "bottom-angle-right" ) . '>Bottom Angle Right</option>';
    echo '</select>';
    echo '</div>';

    echo '<div class="meta-input">';
    echo '<label for="mta_page_gated_content_content_header_bg">';
    echo '<strong><p>Select the background style for the section header.</p></strong>';
    echo '</label>';
    echo '<select name="mta_page_gated_content_content_header_bg" id="mta_page_gated_content_content_header_bg">';
    echo '<option value="" '. selected( $header_bg, "" ) . '>None</option>';
    echo '<option value="white" '. selected( $header_bg, "white" ) . '>White</option>';
    echo '<option value="orange" '. selected( $header_bg, "orange" ) . '>Orange</option>';
    echo '</select>';
    echo '</div>';

    echo '<div class="meta-input">';
    echo '<label for="mta_page_gated_content_content_header_position">';
    echo '<strong><p>Select the display style for the page header.</p></strong>';
    echo '</label>';
    echo '<select name="mta_page_gated_content_content_header_position" id="mta_page_gated_content_content_header_position">';
    echo '<option value="" '. selected( $header_position, "" ) . '>Full</option>';
    echo '<option value="left-half" '. selected( $header_position, "left-half" ) . '>Left Half</option>';
    echo '<option value="left-two-thirds" '. selected( $header_position, "left-two-thirds" ) . '>Left Two Thirds</option>';
    echo '</select>';
    echo '</div>';

    echo '</div>';
    echo '</div>';

    echo '<div class="row">';
    echo '<div class="col-md-12">';
    echo '<div class="meta-input">';
    echo '<label for="mta_page_gated_content_content_superheadline">';
    echo '<strong><p>Super Headline (Gated Content Section)</p></strong>';
    echo '</label>';
    echo '<input type="input" name="mta_page_gated_content_content_superheadline" value="'.esc_attr($superheadline).'">';
    echo '</div>';

    echo '<div class="meta-input">';
    echo '<label for="mta_page_gated_content_content_headline">';
    echo '<strong><p>Headline (Gated Content Section)</p></strong>';
    echo '</label>';
    echo '<input type="input" name="mta_page_gated_content_content_headline" value="'.esc_attr($headline).'">';
    echo '</div>';

    echo '<div class="meta-input">';
    echo '<label for="mta_page_gated_content_content_subheadline">';
    echo '<strong><p>Subheadline (Gated Content Section)</p></strong>';
    echo '</label>';
    echo '<input type="input" name="mta_page_gated_content_content_subheadline" value="'.esc_attr($subheadline).'">';
    echo '</div>';

    echo '<div class="meta-input">';
    echo '<label for="mta_page_gated_content_content_text">';
    echo '<strong><p>Paragraph Text (Gated Content Section)</p></strong>';
    echo '</label>';
    echo '<textarea name="mta_page_gated_content_content_text">'.esc_attr($text).'</textarea>';
    echo '</div>';

    echo '</div>';//close col-md-12
    echo '</div>';//close row

    echo '<div class="row">';
    echo '<div class="col-md-12">';
    echo '<div><h3>Gated Content Content Display</h3></div>';
    echo '<div class="meta-input">';
    echo $gated_content_taxonomy_markup;
    echo '</div>';
    echo '</div>';
    echo '</div>';

    echo '</div>';//close container-fluid
    echo '</div>';//close bootstrap-wrapper

    */
  }


  /**

    /**
   * Save the meta when the post is saved.
   *
   * @param int $post_id The ID of the post being saved.
   */
  public function save($post_id) {
    /*
     * We need to verify this came from the our screen and with
     * proper authorization,
     * because save_post can be triggered at other times.
     */

    // Check if our nonce is set.
    if (!isset($_POST['mta_gated_content_nonce_check_value']))
      return $post_id;

    $nonce = $_POST['mta_gated_content_nonce_check_value'];

    // Verify that the nonce is valid.
    if (!wp_verify_nonce($nonce, 'mta_gated_content_nonce_check'))
      return $post_id;

    // If this is an autosave, our form has not been submitted,
    //     so we don't want to do anything.
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE)
      return $post_id;

    // Check the user's permissions.
    if ('page' == $_POST['post_type']) {

      if (!current_user_can('edit_page', $post_id))
        return $post_id;

    } else {

      if (!current_user_can('edit_post', $post_id))
        return $post_id;
    }

    /* OK, its safe for us to save the data now. */
    $allowed_input_text = array(
      'strong' => array(),
      'br' => array(),
      'em' => array(),
      'i' => array(
      'class' => array(),
      'aria-hidden' => array(),
    ),
      'span' => array(
      'class' => array() // allow spans to have a class added to them
    ),
    );
    $allowed_input_textarea = array(
      'strong' => array(),
      'br' => array(),
      'em' => array(),
      'span' => array(
      'class' => array() // allow spans to have a class added to them
    ),
    );
    $allowed_btn_text = array();
    $allowed_url_text = array();

    $header_style_btm = wp_kses( $_POST['mta_page_gated_content_content_header_style_top'], array() );
    if( isset( $header_style_btm ) )
      update_post_meta($post_id, '_mta_page_gated_content_content_header_style_top', $header_style_btm);

    $header_style_top = wp_kses( $_POST['mta_page_gated_content_content_header_style_btm'], array() );
    if( isset( $header_style_top ) )
      update_post_meta($post_id, '_mta_page_gated_content_content_header_style_btm', $header_style_top);

    $header_bg = wp_kses( $_POST['mta_page_gated_content_content_header_bg'], array() );
    if( isset( $header_bg ) )
      update_post_meta($post_id, '_mta_page_gated_content_content_header_bg', $header_bg);

    $header_position = wp_kses( $_POST['mta_page_gated_content_content_header_position'], array() );
    if( isset( $header_position ) )
      update_post_meta($post_id, '_mta_page_gated_content_content_header_position', $header_position);

    $superheadline = wp_kses( $_POST['mta_page_gated_content_content_superheadline'], $allowed_input_text );
    if( isset( $superheadline ) )
      update_post_meta($post_id, '_mta_page_gated_content_content_superheadline', $superheadline);

    $headline = wp_kses( $_POST['mta_page_gated_content_content_headline'], $allowed_input_text );
    if( isset( $headline ) )
      update_post_meta($post_id, '_mta_page_gated_content_content_headline', $headline);

    $subheadline = wp_kses( $_POST['mta_page_gated_content_content_subheadline'], $allowed_input_text );
    if( isset( $subheadline ) )
      update_post_meta($post_id, '_mta_page_gated_content_content_subheadline', $subheadline);

    $text = wp_kses( $_POST['mta_page_gated_content_content_text'], $allowed_input_textarea );
    if( isset( $text ) )
      update_post_meta($post_id, '_mta_page_gated_content_content_text', $text);

    $gated_content_tax = wp_kses( $_POST['mta_page_gated_content_content_svcs_display_tax'], array() );
    if( isset( $gated_content_tax ) )
      update_post_meta($post_id, 'mta_page_gated_content_content_svcs_display_tax', $gated_content_tax);







    if(isset($_POST['gated_content_intro_text'])) {
      update_post_meta($post->ID, "gated_content_intro_text", $_POST["gated_content_intro_text"]);
    }
    if(isset($_POST['gated_content_logo'])) {
      update_post_meta($post->ID, "gated_content_logo", $_POST["gated_content_logo"]);
    }
    if(isset($_POST['gated_content_screen_shot'])) {
      update_post_meta($post->ID, "gated_content_screen_shot", $_POST["gated_content_screen_shot"]);
    }
    if(isset($_POST['gated_content_main_content_headline'])) {
      update_post_meta($post->ID, "gated_content_main_content_headline", $_POST["gated_content_main_content_headline"]);
    }
    if(isset($_POST['gated_content_main_content_top_text'])) {
      update_post_meta($post->ID, "gated_content_main_content_top_text", $_POST["gated_content_main_content_top_text"]);
    }
    if(isset($_POST['gated_content_main_content_quote'])) {
      update_post_meta($post->ID, "gated_content_main_content_quote", $_POST["gated_content_main_content_quote"]);
    }
    if(isset($_POST['gated_content_main_content_bottom_text'])) {
      update_post_meta($post->ID, "gated_content_main_content_bottom_text", $_POST["gated_content_main_content_bottom_text"]);
    }
    if(isset($_POST['gated_content_customer_quote'])) {
      update_post_meta($post->ID, "gated_content_customer_quote", $_POST["gated_content_customer_quote"]);
    }
    if(isset($_POST['gated_content_customer_quote_name'])) {
      update_post_meta($post->ID, "gated_content_customer_quote_name", $_POST["gated_content_customer_quote_name"]);
    }
    if(isset($_POST['gated_content_customer_quote_name_info'])) {
      update_post_meta($post->ID, "gated_content_customer_quote_name_info", $_POST["gated_content_customer_quote_name_info"]);
    }
    if(isset($_POST['carousel_headline'])) {
      update_post_meta($post->ID, "carousel_headline", $_POST["carousel_headline"]);
    }
    /*
  if(isset($_POST['carousel_sub_headline'])) {
     update_post_meta($post->ID, "carousel_sub_headline", $_POST["carousel_sub_headline"]);
    }
  */
    if(isset($_POST['carousel_top_text'])) {
      update_post_meta($post->ID, "carousel_top_text", $_POST["carousel_top_text"]);
    }
    if(isset($_POST['carousel_img_1'])) {
      update_post_meta($post->ID, "carousel_img_1", $_POST["carousel_img_1"]);
    }
    if(isset($_POST['carousel_img_2'])) {
      update_post_meta($post->ID, "carousel_img_2", $_POST["carousel_img_2"]);
    }
    if(isset($_POST['carousel_img_3'])) {
      update_post_meta($post->ID, "carousel_img_3", $_POST["carousel_img_3"]);
    }
    if(isset($_POST['carousel_img_4'])) {
      update_post_meta($post->ID, "carousel_img_4", $_POST["carousel_img_4"]);
    }
    if(isset($_POST['carousel_img_5'])) {
      update_post_meta($post->ID, "carousel_img_5", $_POST["carousel_img_5"]);
    }
    if(isset($_POST['carousel_img_6'])) {
      update_post_meta($post->ID, "carousel_img_6", $_POST["carousel_img_6"]);
    }
    if(isset($_POST['carousel_img_7'])) {
      update_post_meta($post->ID, "carousel_img_7", $_POST["carousel_img_7"]);
    }
    if(isset($_POST['carousel_img_8'])) {
      update_post_meta($post->ID, "carousel_img_8", $_POST["carousel_img_8"]);
    }


    if(isset($_POST['gated_content_results_super_headline'])) {
      update_post_meta($post->ID, "gated_content_results_super_headline", $_POST["gated_content_results_super_headline"]);
    }
    if(isset($_POST['gated_content_results_headline'])) {
      update_post_meta($post->ID, "gated_content_results_headline", $_POST["gated_content_results_headline"]);
    }
    if(isset($_POST['gated_content_results_top_text'])) {
      update_post_meta($post->ID, "gated_content_results_top_text", $_POST["gated_content_results_top_text"]);
    }
    if(isset($_POST['gated_content_results_number_one'])) {
      update_post_meta($post->ID, "gated_content_results_number_one", $_POST["gated_content_results_number_one"]);
    }
    if(isset($_POST['gated_content_results_number_one_text'])) {
      update_post_meta($post->ID, "gated_content_results_number_one_text", $_POST["gated_content_results_number_one_text"]);
    }
    if(isset($_POST['gated_content_results_number_two'])) {
      update_post_meta($post->ID, "gated_content_results_number_two", $_POST["gated_content_results_number_two"]);
    }
    if(isset($_POST['gated_content_results_number_two_text'])) {
      update_post_meta($post->ID, "gated_content_results_number_two_text", $_POST["gated_content_results_number_two_text"]);
    }
    if(isset($_POST['gated_content_results_number_three'])) {
      update_post_meta($post->ID, "gated_content_results_number_three", $_POST["gated_content_results_number_three"]);
    }
    if(isset($_POST['gated_content_results_number_three_text'])) {
      update_post_meta($post->ID, "gated_content_results_number_three_text", $_POST["gated_content_results_number_three_text"]);
    }
    if(isset($_POST['gated_content_results_url'])) {
      update_post_meta($post->ID, "gated_content_results_url", $_POST["gated_content_results_url"]);
    }








  }





  /**
   * Save the meta when the post is saved.
   *
   * @param int $post_id The ID of the post being saved.
   */
  public function save_gated_content_post($post_id) {
    /*
     * We need to verify this came from the our screen and with
     * proper authorization,
     * because save_post can be triggered at other times.
     */

    // Check if our nonce is set.
    if (!isset($_POST['mta_gated_content_post_nonce_check_value']))
      return $post_id;

    $nonce = $_POST['mta_gated_content_post_nonce_check_value'];

    // Verify that the nonce is valid.
    if (!wp_verify_nonce($nonce, 'mta_gated_content_post_nonce_check'))
      return $post_id;

    // If this is an autosave, our form has not been submitted,
    //     so we don't want to do anything.
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE)
      return $post_id;

    // Check the user's permissions.
    if ('page' == $_POST['post_type']) {

      if (!current_user_can('edit_page', $post_id))
        return $post_id;

    } else {

      if (!current_user_can('edit_post', $post_id))
        return $post_id;
    }

    /* OK, its safe for us to save the data now. */
    $allowed_input_text = array(
      'strong' => array(),
      'br' => array(),
      'em' => array(),
      'i' => array(
      'class' => array(),
      'aria-hidden' => array(),
    ),
      'span' => array(
      'class' => array() // allow spans to have a class added to them
    ),
    );
    $allowed_input_textarea = array(
      'strong' => array(),
      'br' => array(),
      'em' => array(),
      'span' => array(
      'class' => array() // allow spans to have a class added to them
    ),
    );
    $allowed_btn_text = array();
    $allowed_url_text = array();


    $mta_leadgen_gated_gform_id = wp_kses( $_POST['mta_leadgen_gated_gform_id'], array() );
    if( isset( $mta_leadgen_gated_gform_id ) )
      update_post_meta($post_id, '_mta_leadgen_gated_gform_id', $mta_leadgen_gated_gform_id);

    $mta_leadgen_gated_ty_display = wp_kses( $_POST['mta_leadgen_gated_ty_display'], array() );
    if( isset( $mta_leadgen_gated_ty_display ) )
      update_post_meta($post_id, '_mta_leadgen_gated_ty_display', $mta_leadgen_gated_ty_display);

    $mta_leadgen_gated_access_period = wp_kses( $_POST['mta_leadgen_gated_access_period'], array() );
    if( isset( $mta_leadgen_gated_access_period ) )
      update_post_meta($post_id, '_mta_leadgen_gated_access_period', $mta_leadgen_gated_access_period);

    /*

    $gated_content_bullet_1 = wp_kses( $_POST['gated_content_bullet_1'], $allowed_input_text );
    if( isset( $gated_content_bullet_1 ) )
      update_post_meta($post_id, 'gated_content_bullet_1', $gated_content_bullet_1);

    $gated_content_bullet_2 = wp_kses( $_POST['gated_content_bullet_2'], $allowed_input_text );
    if( isset( $gated_content_bullet_2 ) )
      update_post_meta($post_id, 'gated_content_bullet_2', $gated_content_bullet_2);

    $gated_content_bullet_3 = wp_kses( $_POST['gated_content_bullet_3'], $allowed_input_text );
    if( isset( $gated_content_bullet_3 ) )
      update_post_meta($post_id, 'gated_content_bullet_3', $gated_content_bullet_3);

    $gated_content_bullet_4 = wp_kses( $_POST['gated_content_bullet_4'], $allowed_input_text );
    if( isset( $gated_content_bullet_4 ) )
      update_post_meta($post_id, 'gated_content_bullet_4', $gated_content_bullet_4);

    $gated_content_section_bg = wp_kses( $_POST['gated_content_section_bg'], array() );
    if( isset( $gated_content_section_bg ) )
      update_post_meta($post_id, 'gated_content_section_bg', $gated_content_section_bg);
      */



  }
  /*
   * Register the stylesheets for the admin area.
   *
   * @since    1.0.0
   */
  public function enqueue_styles() {

    /**
     * This function is provided for demonstration purposes only.
     *
     * An instance of this class should be passed to the run() function
     * defined in Mta_Gated_Content_Loader as all of the hooks are defined
     * in that particular class.
     *
     * The Mta_Gated_Content_Loader will then create the relationship
     * between the defined hooks and the functions defined in this
     * class.
     */

    wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/mta-gated_content-admin.css', array(), $this->version, 'all' );

  }


  /**
   * Register the JavaScript for the admin area.
   *
   * @since    1.0.0
   */
  public function enqueue_scripts() {

    /**
     * This function is provided for demonstration purposes only.
     *
     * An instance of this class should be passed to the run() function
     * defined in Mta_Gated_Content_Loader as all of the hooks are defined
     * in that particular class.
     *
     * The Mta_Gated_Content_Loader will then create the relationship
     * between the defined hooks and the functions defined in this
     * class.
     */

    wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/mta-gated_content-admin.js', array( 'jquery' ), $this->version, false );



  }


  /*

  $labels = array(

  );

  $args = array(

    );




  register_post_type( 'gated_content' , $args );

  */
  public function mta_gated_content_post_type() {
    $labels = array(
      'name' => _x('Gated Content', 'post type general name'),
      'singular_name' => _x('Resource', 'post type singular name'),
      'add_new' => _x('Add New Gated Content', 'gated_content'),
      'add_new_item' => __('Add New Gated Content'),
      'edit_item' => __('Edit Gated Content'),
      'new_item' => __('New Gated Content'),
      'view_item' => __('View Gated Content'),
      'search_items' => __('Search Gated Content'),
      'not_found' =>  __('Nothing found'),
      'not_found_in_trash' => __('Nothing found in Trash'),
      'parent_item_colon' => ''
    );
    $args = array(
      'labels' => $labels,
      'public' => true,
      'publicly_queryable' => true,
      'exclude_from_search' => true,
      'show_ui' => true,
      'query_var' => true,
      'rewrite' => array(
      'slug' => 'gated-content',
      'with_front' => false,
    ),
      'show_in_menu' => false,

      'capability_type' => 'post',
      'hierarchical' => false,
      'supports' => array('title', 'editor', 'revisons')
    );
    register_post_type( 'gated_content' , $args );

    // Initialize New Taxonomy Labels
    /*
    $labels = array(
      'name' => _x( 'Display Category', 'taxonomy general name' ,'mta_gated_content_content'),
      'singular_name' => _x( 'Display Category', 'taxonomy singular name' ,'mta_gated_content_content'),
      'search_items' =>  __( 'Search Types' ,'mta_gated_content_content'),
      'all_items' => __( 'All Categories' ,'mta_gated_content_content'),
      'parent_item' => __( 'Parent Category' ,'mta_gated_content_content'),
      'parent_item_colon' => __( 'Parent Category:','mta_gated_content_content'),
      'edit_item' => __( 'Edit Categories' ,'mta_gated_content_content'),
      'update_item' => __( 'Update Category' ,'mta_gated_content_content'),
      'add_new_item' => __( 'Add New Category','mta_gated_content_content' ),
      'new_item_name' => __( 'New Category Name' ,'mta_gated_content_content'),
    );

    // Custom taxonomy for Project Tags
    register_taxonomy(
      'madtown_gated_content',
      array('gated_content'),
      array(
      'hierarchical' => true,
      'labels' => $labels,
      'show_ui' => true,
      'query_var' => true,
      'rewrite' => array(
      'slug' => 'gated_content-display'
    ),
    )
    );
    */
  }

}



























/*


function save_gated_content(){
  global $post;

  if ( defined('DOING_AUTOSAVE') && DOING_AUTOSAVE ) {
    if (isset($post_id)) {
      return $post_id;
    }
  }
  if(isset($_POST['individual_page'])) {
    update_post_meta($post->ID, "individual_page", $_POST["individual_page"]);
  }
  if(isset($_POST['gated_content_bullet_1'])) {
    update_post_meta($post->ID, "gated_content_bullet_1", $_POST["gated_content_bullet_1"]);
  }
  if(isset($_POST['gated_content_bullet_2'])) {
    update_post_meta($post->ID, "gated_content_bullet_2", $_POST["gated_content_bullet_2"]);
  }
  if(isset($_POST['gated_content_bullet_3'])) {
    update_post_meta($post->ID, "gated_content_bullet_3", $_POST["gated_content_bullet_3"]);
  }
  if(isset($_POST['gated_content_bullet_4'])) {
    update_post_meta($post->ID, "gated_content_bullet_4", $_POST["gated_content_bullet_4"]);
  }
  if(isset($_POST['gated_content_section_bg'])) {
    update_post_meta($post->ID, "gated_content_section_bg", $_POST["gated_content_section_bg"]);
  }
}


add_action("manage_posts_custom_column",  "gated_content_custom_columns");
add_filter("manage_edit-gated_content_columns", "gated_content_edit_columns");

function gated_content_edit_columns($columns){
  $columns = array(
    "cb" => "<input type=\"checkbox\" />",
    "title" => "Gated Content Name",
    //"gated_content_icon" => "Icon",
    //"gated_content_super_headline" => "Position",
  );

  return $columns;
}
function gated_content_custom_columns($column){
  global $post;

  switch ($column) {
   // case "gated_content_icon":
   //   $custom = get_post_custom();
   //   echo $custom["gated_content_icon"][0];
   //   break;
   // case "gated_content_super_headline":
   //   $custom = get_post_custom();
   //   echo $custom["gated_content_super_headline"][0];
   //   break;
  }
}



*/



